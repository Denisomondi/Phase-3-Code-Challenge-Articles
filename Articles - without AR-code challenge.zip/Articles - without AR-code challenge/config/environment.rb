require 'bundler/setup'
Bundler.require
require_rel '../app'